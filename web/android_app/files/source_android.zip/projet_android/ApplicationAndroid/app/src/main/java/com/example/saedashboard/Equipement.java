package com.example.saedashboard; // VERIFIE QUE C'EST LA PREMIERE LIGNE

public class Equipement {
    private String ip;
    private String os;
    private String details;
    private int statut;

    public Equipement(String ip, String os, int statut, String details) {
        this.ip = ip;
        this.os = os;
        this.details = details;
        this.statut = statut;
    }

    public String getIp() { return ip; }
    public String getOs() { return os; }
    public String getDetails() { return details; }
    public int getStatut() { return statut; }
}