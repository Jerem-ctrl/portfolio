package com.example.saedashboard;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;

public class ScanActivity extends AppCompatActivity {

    // ⚠️ TON IP
    private static final String API_URL = "http://192.168.1.85/sae302/api.php";

    private Spinner spinnerNetworks;
    private TextView tvStatus;
    private Button btnLaunch;

    // Liste pour stocker les réseaux (ex: 192.168.1.0/24)
    private List<String> networkList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scan);

        spinnerNetworks = findViewById(R.id.spinnerNetworks);
        btnLaunch = findViewById(R.id.btnLaunchScan);
        tvStatus = findViewById(R.id.tvStatus);

        // 1. Au démarrage, on va chercher les réseaux dispos sur le serveur
        chargerReseauxDistants();

        btnLaunch.setOnClickListener(v -> {
            // On récupère l'élément sélectionné dans le menu déroulant
            if (spinnerNetworks.getSelectedItem() != null) {
                String selectedTarget = spinnerNetworks.getSelectedItem().toString();
                lancerScanDistant(selectedTarget);
            } else {
                Toast.makeText(this, "Aucun réseau sélectionné", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // --- FONCTION 1 : CHARGER LA LISTE (GET) ---
    private void chargerReseauxDistants() {
        tvStatus.setText("Chargement des réseaux...");
        btnLaunch.setEnabled(false); // On désactive le bouton tant qu'on a pas la liste

        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                // On appelle api.php?action=get_networks
                URL url = new URL(API_URL + "?action=get_networks");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");

                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) response.append(line);
                reader.close();

                // On transforme le JSON [ "192...", "10..." ] en liste Java
                JSONArray jsonArray = new JSONArray(response.toString());
                networkList.clear();
                for (int i = 0; i < jsonArray.length(); i++) {
                    networkList.add(jsonArray.getString(i));
                }

                // Mise à jour de l'interface (Spinner)
                runOnUiThread(() -> {
                    if (networkList.isEmpty()) {
                        tvStatus.setText("Aucun réseau trouvé sur le serveur.");
                    } else {
                        // On remplit le menu déroulant
                        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                                this,
                                android.R.layout.simple_spinner_dropdown_item,
                                networkList
                        );
                        spinnerNetworks.setAdapter(adapter);
                        tvStatus.setText("Réseaux chargés.");
                        btnLaunch.setEnabled(true);
                    }
                });

            } catch (Exception e) {
                runOnUiThread(() -> tvStatus.setText("Erreur chargement : " + e.getMessage()));
            }
        });
    }

    // --- FONCTION 2 : LANCER LE SCAN (POST) ---
    private void lancerScanDistant(String target) {
        tvStatus.setText("Envoi de la demande...");

        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                URL url = new URL(API_URL);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json; utf-8");
                conn.setDoOutput(true);

                JSONObject jsonInput = new JSONObject();
                jsonInput.put("action", "lancer_scan");
                jsonInput.put("target", target);

                try (OutputStream os = conn.getOutputStream()) {
                    byte[] input = jsonInput.toString().getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                int code = conn.getResponseCode();
                runOnUiThread(() -> {
                    if (code == 200) {
                        tvStatus.setText("✅ Scan démarré sur " + target);
                        Toast.makeText(this, "Scan lancé !", Toast.LENGTH_LONG).show();

                        btnLaunch.setEnabled(false);
                        btnLaunch.setText("SCAN EN COURS...");

                    } else {
                        tvStatus.setText("❌ Erreur serveur : " + code);
                    }
                });

            } catch (Exception e) {
                runOnUiThread(() -> tvStatus.setText("Erreur scan : " + e.getMessage()));
            }
        });
    }
}