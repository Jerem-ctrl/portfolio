package com.example.saedashboard; // VERIFIE QUE C'EST LA PREMIERE LIGNE

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class EquipementAdapter extends RecyclerView.Adapter<EquipementAdapter.ViewHolder> {

    private List<Equipement> equipements;
    private Context context; // <--- 1. On déclare le contexte ICI (à l'intérieur)

    // <--- 2. On modifie le constructeur pour accepter le Contexte
    public EquipementAdapter(Context context, List<Equipement> equipements) {
        this.context = context;
        this.equipements = equipements;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_equipement, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Equipement eq = equipements.get(position);
        holder.txtIp.setText(eq.getIp());

        // Attention: Assure-toi d'utiliser le bon getter (getNom ou getOs selon ton fichier Equipement.java)
        holder.txtOs.setText(eq.getOs());

        // Gestion de la couleur (Vert/Rouge)
        if (eq.getStatut() == 1) {
            holder.viewStatus.setBackgroundColor(Color.GREEN);
        } else {
            holder.viewStatus.setBackgroundColor(Color.RED);
        }

        // --- NOUVEAU : LE CLIC ---
        holder.itemView.setOnClickListener(v -> {
            // On prépare le changement de page
            Intent intent = new Intent(context, DetailActivity.class);

            // On envoie les infos à la nouvelle page
            intent.putExtra("IP_MACHINE", eq.getIp());

            // Assure-toi d'avoir ajouté getDetails() dans Equipement.java avant !
            intent.putExtra("DETAILS_MACHINE", eq.getDetails());

            // On lance la page
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return equipements.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView txtIp, txtOs;
        public View viewStatus;

        public ViewHolder(View v) {
            super(v);
            txtIp = v.findViewById(R.id.txtIp);
            txtOs = v.findViewById(R.id.txtOs);
            viewStatus = v.findViewById(R.id.viewStatus);
        }
    }
}