package com.example.saedashboard;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class DetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        // 1. Récupération des éléments
        TextView tvTitle = findViewById(R.id.tvDetailTitle);
        LinearLayout containerPorts = findViewById(R.id.containerPorts); // Le nouveau conteneur
        Button btnBack = findViewById(R.id.btnBack);

        // 2. Récupération données
        String ip = getIntent().getStringExtra("IP_MACHINE");
        String rawData = getIntent().getStringExtra("DETAILS_MACHINE"); // ou "DETAILS_MACHINE"

        if (ip != null) tvTitle.setText("Machine : " + ip);

        // 3. Génération de l'interface PRO
        if (rawData != null && !rawData.isEmpty()) {
            genererInterfacePro(containerPorts, rawData);
        } else {
            afficherMessageVide(containerPorts);
        }

        btnBack.setOnClickListener(v -> finish());
    }

    // --- FONCTION QUI DESSINE L'INTERFACE ---
    private void genererInterfacePro(LinearLayout container, String data) {
        // On découpe le texte ligne par ligne
        String[] lines = data.split("\n");

        for (String line : lines) {
            line = line.trim();
            if (line.isEmpty()) continue;

            // CAS 1 : C'est un PORT (ex: "- Port 80 : OUVERT (http)")
            if (line.startsWith("- Port") || line.contains("Port")) {
                ajouterCartePort(container, line);
            }
            // CAS 2 : C'est une VULNÉRABILITÉ (ex: "⚠️ Faille détectée")
            else if (line.contains("⚠️") || line.contains("Faille")) {
                ajouterCarteFaille(container, line);
            }
            // CAS 3 : Titres ou autre
            else if (line.contains("PORTS") || line.contains("FAILLES")) {
                // On ignore les titres bruts, on a nos propres cartes
            }
        }
    }

    private void ajouterCartePort(LinearLayout container, String line) {
        // 1. Création de la Carte Blanche
        CardView card = new CardView(this);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        params.setMargins(0, 0, 0, 20); // Marge en bas
        card.setLayoutParams(params);
        card.setCardBackgroundColor(Color.WHITE);
        card.setRadius(15);
        card.setCardElevation(5);

        // 2. Contenu de la carte (Horizontal)
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.HORIZONTAL);
        content.setPadding(30, 30, 30, 30);
        content.setGravity(Gravity.CENTER_VERTICAL);

        // 3. Pastille Verte (Visualisation visuelle)
        TextView statusDot = new TextView(this);
        statusDot.setText("●");
        statusDot.setTextSize(20);
        statusDot.setTextColor(Color.parseColor("#10b981")); // Vert Émeraude
        statusDot.setPadding(0, 0, 20, 0);

        // 4. Texte du Port (Nettoyage du texte pour faire propre)
        // On enlève le tiret du début pour avoir juste "Port 80 : ..."
        String cleanText = line.replace("- ", "").replace("🔴", "").replace("🔵", "");

        TextView textInfo = new TextView(this);
        textInfo.setText(cleanText);
        textInfo.setTextColor(Color.parseColor("#1e293b")); // Gris foncé pro
        textInfo.setTextSize(16);
        textInfo.setTypeface(null, Typeface.BOLD);

        // 5. Assemblage
        content.addView(statusDot);
        content.addView(textInfo);
        card.addView(content);
        container.addView(card);
    }

    private void ajouterCarteFaille(LinearLayout container, String line) {
        // Carte Rouge pour les failles
        CardView card = new CardView(this);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        params.setMargins(0, 0, 0, 20);
        card.setLayoutParams(params);
        card.setCardBackgroundColor(Color.parseColor("#fee2e2")); // Rouge très pâle
        card.setRadius(15);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL); // Vertical pour lire le détail
        content.setPadding(30, 30, 30, 30);

        TextView textAlert = new TextView(this);
        textAlert.setText(line);
        textAlert.setTextColor(Color.parseColor("#b91c1c")); // Rouge foncé
        textAlert.setTextSize(14);
        textAlert.setTypeface(null, Typeface.BOLD);

        content.addView(textAlert);
        card.addView(content);
        container.addView(card);
    }

    private void afficherMessageVide(LinearLayout container) {
        TextView tv = new TextView(this);
        tv.setText("Aucune donnée disponible.");
        tv.setTextColor(Color.GRAY);
        tv.setGravity(Gravity.CENTER);
        container.addView(tv);
    }
}