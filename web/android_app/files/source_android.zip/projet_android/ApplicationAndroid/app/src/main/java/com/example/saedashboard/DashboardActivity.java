package com.example.saedashboard;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast; // Pour le feedback visuel (optionnel)
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class DashboardActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private EquipementAdapter adapter;
    private List<Equipement> equipementList = new ArrayList<>();

    // URL DE TON API
    private static final String API_URL = "http://192.168.1.85/SAE_302/api.php";

    // --- NOUVEAU : GESTION DU RAFRAICHISSEMENT AUTO ---
    private Handler handler = new Handler(Looper.getMainLooper());
    private Runnable refreshRunnable;
    private boolean isPaused = false;
    // --------------------------------------------------

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        FloatingActionButton fab = findViewById(R.id.fabAddScan);
        fab.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, ScanActivity.class);
            startActivity(intent);
        });

        recyclerView = findViewById(R.id.rvEquipements);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new EquipementAdapter(this, equipementList);
        recyclerView.setAdapter(adapter);

        // --- DÉFINITION DE LA TÂCHE RÉPÉTITIVE ---
        refreshRunnable = new Runnable() {
            @Override
            public void run() {
                if (!isPaused) {
                    chargerDonnees(); // On charge les données
                    // On relance ce même code dans 5 secondes (5000 ms)
                    handler.postDelayed(this, 5000);
                }
            }
        };
    }

    // QUAND L'ÉCRAN APPARAÎT -> ON DÉMARRE LA BOUCLE
    @Override
    protected void onResume() {
        super.onResume();
        isPaused = false;
        chargerDonnees(); // Chargement immédiat
        handler.postDelayed(refreshRunnable, 5000); // Puis boucle toutes les 5s
        // Petit message pour dire que c'est vivant
        // Toast.makeText(this, "Suivi temps réel activé", Toast.LENGTH_SHORT).show();
    }

    // QUAND ON QUITTE L'ÉCRAN -> ON ARRÊTE TOUT (Pour pas vider la batterie)
    @Override
    protected void onPause() {
        super.onPause();
        isPaused = true;
        handler.removeCallbacks(refreshRunnable);
    }

    private void chargerDonnees() {
        ExecutorService executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            try {
                URL url = new URL(API_URL);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(2000); // Timeout court pour pas bloquer

                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();

                JSONArray jsonArray = new JSONArray(response.toString());

                // On prépare une nouvelle liste temporaire
                List<Equipement> nouvelleListe = new ArrayList<>();

                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject obj = jsonArray.getJSONObject(i);
                    String ip = obj.getString("ip");
                    String nom = obj.optString("nom", "Inconnu");
                    String details = obj.optString("details", "");
                    int statut = obj.optInt("statut", 0);

                    nouvelleListe.add(new Equipement(ip, nom, statut, details));
                }

                // MISE À JOUR DE L'INTERFACE
                runOnUiThread(() -> {
                    // On remplace la liste actuelle par la nouvelle
                    equipementList.clear();
                    equipementList.addAll(nouvelleListe);
                    adapter.notifyDataSetChanged();
                });

            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}