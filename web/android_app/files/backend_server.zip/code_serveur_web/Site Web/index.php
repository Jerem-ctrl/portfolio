<?php
session_start();
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit; }

$bddPath = '/var/www/html/SAE_302/bdd.db';
try {
    $pdo = new PDO('sqlite:' . $bddPath, null, null, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
} catch (Exception $e) { die("Erreur BDD"); }

$outputLog = "";
if (isset($_POST['btnScanGlobal'])) {
    $subnet = escapeshellarg($_POST['choixReseau']);
    $outil  = escapeshellarg($_POST['choixOutil'] ?? 'NMAP');
    $cmd    = "cd /var/www/html/SAE_302 && java -jar scan.jar GLOBAL $subnet $outil 2>&1";
    $outputLog = "--- SCAN EN COURS ($outil) ---\n" . shell_exec($cmd);
}

function getNetworks() {
    exec("ip -o -4 addr show", $out);
    $nets = [];
    foreach ($out as $line) {
        if (strpos($line, '127.0.0.1')) continue;
        if (preg_match('/inet\s([0-9\.\/]+)/', $line, $m)) {
            list($ip, $mask) = explode('/', $m[1]);
            $net = long2ip(ip2long($ip) & (-1 << (32 - $mask)));
            $nets[] = "$net/$mask";
        }
    }
    return $nets;
}

$equipements = $pdo->query("SELECT e.*, (SELECT COUNT(*) FROM vulnerabilites v WHERE v.id_equipement = e.id) as nb_failles FROM equipements e ORDER BY ip ASC")->fetchAll(PDO::FETCH_ASSOC);
$failles = $pdo->query("SELECT v.*, e.ip FROM vulnerabilites v JOIN equipements e ON v.id_equipement = e.id ORDER BY e.ip ASC")->fetchAll(PDO::FETCH_ASSOC);

function getOSIcon($os) {
    if (stripos($os, 'Linux') !== false) return "🐧";
    if (stripos($os, 'Windows') !== false) return "🪟";
    if (stripos($os, 'Android') !== false) return "🤖";
    return "❓";
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>SAE 3.02 - Dashboard</title>
    <link rel="stylesheet" href="./styles.css">
</head>
<body>
<div class="container">
    <div class="header-main">
        <h1>🛡️ Dashboard Surveillance</h1>
        <a href="logout.php">Se déconnecter</a>
    </div>

    <div class="section">
        <span class="section-title">Scanner le Réseau</span>
        <form method="post" class="scan-form" style="display:flex; gap:10px; margin-top:15px;">
            <select name="choixReseau" class="custom-select">
                <?php foreach (getNetworks() as $net): ?>
                    <option value="<?= $net ?>">Réseau <?= $net ?></option>
                <?php endforeach; ?>
            </select>
            <select name="choixOutil" class="custom-select">
                <option value="NMAP">Nmap</option>
                <option value="AUDIT">Extension</option>
            </select>
            <button type="submit" name="btnScanGlobal" class="btn-action btn-scan">LANCER</button>
        </form>
        <?php if($outputLog): ?>
            <pre class="console-log"><?= htmlspecialchars($outputLog) ?></pre>
        <?php endif; ?>
    </div>

    <div class="section">
        <span class="section-title">Parc Machines (<?= count($equipements) ?>)</span>
        <table style="width:100%; margin-top:15px;">
            <thead>
                <tr><th>Machine</th><th>MAC</th><th>Services</th><th>Sécurité</th></tr>
            </thead>
            <tbody>
                <?php foreach ($equipements as $eq): ?>
                <tr>
                    <td class="col-ip">
                        <span class="status-dot <?= $eq['statut'] ? 'status-up' : 'status-down' ?>"></span>
                        <span style="font-size:1.2em;"><?= getOSIcon($eq['os_detecte']) ?></span>
                        <strong><?= $eq['ip'] ?></strong>
                    </td>
                    <td><?= $eq['mac_address'] ?: '-' ?></td>
                    <td>
                        <?php
                        $stmt = $pdo->prepare("SELECT port, nom_service FROM services WHERE id_equipement = ?");
                        $stmt->execute([$eq['id']]);
                        while($s = $stmt->fetch()): ?>
                            <span class="tag-port"><?= $s['port'] ?> <?= $s['nom_service'] ?></span>
                        <?php endwhile; ?>
                    </td>
                    <td><?= $eq['nb_failles'] > 0 ? "<span class='tag-danger'>{$eq['nb_failles']} Faille(s)</span>" : "<span class='tag-safe'>Sûr</span>" ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <?php if ($failles): ?>
    <div class="section" style="border-left: 4px solid var(--danger);">
        <span class="section-title" style="color:var(--danger);">Détails des Vulnérabilités</span>
        <table style="width:100%; margin-top:15px;">
            <thead>
                <tr><th>Cible</th><th>Faille</th><th>Sévérité</th><th>Solution</th></tr>
            </thead>
            <tbody>
                <?php foreach ($failles as $f): ?>
                <tr>
                    <td><b><?= $f['ip'] ?></b></td>
                    <td><?= $f['titre_faille'] ?></td>
                    <td style="color:red; font-weight:bold;"><?= strtoupper($f['gravite']) ?></td>
                    <td><?= $f['solution'] ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>
</body>
</html>