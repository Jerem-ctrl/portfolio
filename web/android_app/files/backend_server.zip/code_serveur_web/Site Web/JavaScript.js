  document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('table').forEach(table => {
      const headers = Array.from(table.querySelectorAll('thead th')).map(th => th.innerText.trim().toLowerCase());
      const idx = headers.indexOf('severite') !== -1 ? headers.indexOf('severite') : headers.indexOf('sévérité');
      if (idx === -1) return;
      table.querySelectorAll('tbody tr').forEach(row => {
        const cell = row.cells[idx];
        if (!cell) return;
        const text = cell.innerText.trim().toLowerCase();
        const span = document.createElement('span');
        span.className = 'badge';
        const dot = document.createElement('span');
        dot.className = 'dot';
        span.appendChild(dot);
        const label = document.createElement('span');
        label.textContent = text || 'unknown';
        span.appendChild(label);
        if (text.includes('low')) span.classList.add('low');
        else if (text.includes('medium')) span.classList.add('medium');
        else if (text.includes('high')) span.classList.add('high');
        else if (text.includes('critical')) span.classList.add('critical');
        else {
          span.style.background = 'rgba(255,255,255,0.03)';
          span.style.color = 'var(--muted)';
        }
        cell.innerHTML = '';
        cell.appendChild(span);
      });
    });
  });