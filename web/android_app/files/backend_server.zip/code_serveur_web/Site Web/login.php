<?php
session_start();

$bddPath = '/var/www/html/SAE_302/bdd.db';
$lockTime = 60; 

if (isset($_SESSION['blocked_time'])) {
    $diff = time() - $_SESSION['blocked_time'];
    if ($diff < $lockTime) {
        $error = "⛔ Bloqué. Réessayez dans " . ($lockTime - $diff) . "s.";
    } else {
        unset($_SESSION['blocked_time'], $_SESSION['attempts']);
    }
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && !isset($error)) {
    $user = $_POST['username'] ?? '';
    $pass = $_POST['password'] ?? '';

    try {
        $pdo = new PDO("sqlite:$bddPath", null, null, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        $stmt = $pdo->prepare("SELECT * FROM utilisateurs WHERE username = ?");
        $stmt->execute([$user]);
        $u = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($u && $u['password_hash'] === $pass) {
            $_SESSION['user_id'] = $u['id'];
            $_SESSION['role'] = $u['role'];
            unset($_SESSION['attempts']); 
            header("Location: index.php"); exit;
        } 
        
        $_SESSION['attempts'] = ($_SESSION['attempts'] ?? 0) + 1;
        if ($_SESSION['attempts'] >= 3) {
            $_SESSION['blocked_time'] = time();
            $error = "⛔ Trop d'échecs. Accès bloqué.";
        } else {
            $error = "Identifiants incorrects (" . (3 - $_SESSION['attempts']) . " essais restants).";
        }
    } catch (Exception $e) { $error = "Erreur système."; }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion - Admin</title>
    <link rel="stylesheet" href="./styles.css">
</head>
<body>
<div class="container login-wrapper">
    <div class="login-card">
        <h1>🔐 Accès Admin</h1>
        <p style="color:var(--text-muted); margin-bottom: 20px;">Identification requise</p>

        <?php if (isset($error)): ?>
            <div class="error-msg"><?= $error ?></div>
        <?php endif; ?>

        <?php if (!isset($_SESSION['blocked_time'])): ?>
        <form method="POST">
            <input type="text" name="username" class="form-input" required placeholder="Utilisateur" style="margin-bottom:10px;">
            <input type="password" name="password" class="form-input" required placeholder="Mot de passe" style="margin-bottom:20px;">
            <button type="submit" class="btn-login">Se connecter</button>
        </form>
        <?php endif; ?>
    </div>
</div>
</body>
</html>