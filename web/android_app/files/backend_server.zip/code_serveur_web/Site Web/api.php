<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");

$bddPath = '/var/www/html/SAE_302/bdd.db';

try {
    $db = new PDO('sqlite:' . $bddPath);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["error" => "Erreur BDD: " . $e->getMessage()]);
    exit;
}

if (isset($_GET['action']) && $_GET['action'] === 'get_networks') {
    $networks = [];
    exec("ip -o -4 addr show", $out);
    foreach ($out as $line) {
        if (strpos($line, '127.0.0.1') !== false) continue;
        
        if (preg_match('/inet\s([0-9\.\/]+)/', $line, $m)) {
            $cidr = $m[1];
            list($ip, $mask) = explode('/', $cidr);
            $net = long2ip(ip2long($ip) & (-1 << (32 - $mask)));
            
            $networks[] = "$net/$mask";
        }
    }
    echo json_encode($networks);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $input = json_decode(file_get_contents('php://input'), true);

    if (isset($input['action']) && $input['action'] === 'lancer_scan') {
        
        $reseau = $input['target'];
        
        $reseauSafe = escapeshellarg($reseau);
        $outilSafe = escapeshellarg("NMAP"); 

        $cmd = "cd \"/var/www/html/SAE_302\" && java -jar scan.jar GLOBAL $reseauSafe $outilSafe > /dev/null 2>&1 &";
        
        shell_exec($cmd);

        echo json_encode(["status" => "success", "message" => "Scan démarré sur $reseau"]);
        exit;
    }
}

$query = "SELECT * FROM equipements";
$stmt = $db->query($query);
$machines = $stmt->fetchAll();

$data = [];

foreach ($machines as $machine) {
    $ip = $machine['ip'];
    $id = $machine['id'];
    $details = "";
    $statut = 1; 
    $stmtS = $db->prepare("SELECT * FROM services WHERE id_equipement = :id");
    $stmtS->execute([':id' => $id]);
    $services = $stmtS->fetchAll();

    if (count($services) > 0) {
        $details .= "🔵 ÉTAT DES PORTS :\n";
        foreach ($services as $s) {
            $etat = !empty($s['etat']) ? $s['etat'] : 'OUVERT';
            $details .= "- Port " . $s['port'] . " : " . $etat . " (" . $s['nom_service'] . ")\n";
        }
        $details .= "\n";
    }

    $stmtV = $db->prepare("SELECT * FROM vulnerabilites WHERE id_equipement = :id");
    $stmtV->execute([':id' => $id]);
    $vulns = $stmtV->fetchAll();

    if (count($vulns) > 0) {
        $statut = 0;
        $details .= " FAILLES DÉTECTÉES :\n";
        foreach ($vulns as $v) {
            $details .= "⚠️ " . $v['titre_faille'] . "\n";
            $details .= "   Gravité : " . $v['gravite'] . "\n";
            if (isset($v['solution'])) {
                $details .= "   Solution : " . $v['solution'] . "\n";
            }
            $details .= "\n";
        }
    }

    if (empty($details)) {
        $details = " Aucune information particulière (Scan silencieux).";
    }

    $data[] = [
        "ip" => $machine['ip'],
        "nom" => $machine['nom_hote'] ?? "Inconnu",
        "statut" => $statut,
        "details" => $details 
    ];

}

echo json_encode($data, JSON_PRETTY_PRINT);
?>