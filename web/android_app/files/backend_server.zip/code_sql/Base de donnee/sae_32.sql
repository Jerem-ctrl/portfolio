-- ==============================================================================
-- BASE DE DONNÉES SAE - SURVEILLANCE RÉSEAU
-- ==============================================================================

-- 1. TABLE UTILISATEURS

CREATE TABLE IF NOT EXISTS utilisateurs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(20) DEFAULT 'USER',
    date_creation DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT check_role CHECK (role IN ('ADMIN', 'USER', 'AUDITEUR'))
);

-- 2. TABLE OUTILS

CREATE TABLE IF NOT EXISTS outils (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nom_outil VARCHAR(50) NOT NULL UNIQUE,
    nom_classe_java VARCHAR(100) NOT NULL,
    description TEXT,
    actif INTEGER DEFAULT 1 CHECK (actif IN (0, 1))
);

-- 3. TABLE EQUIPEMENTS

CREATE TABLE IF NOT EXISTS equipements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ip VARCHAR(15) NOT NULL UNIQUE,
    mac_address VARCHAR(17),
    nom_hote VARCHAR(255),
    os_detecte VARCHAR(100),
    statut INTEGER DEFAULT 0 CHECK (statut IN (0, 1)),
    date_maj DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 4. TABLE SCAN_QUEUE (FILE D'ATTENTE)

CREATE TABLE IF NOT EXISTS scan_queue (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    id_utilisateur INTEGER,
    cible VARCHAR(15) NOT NULL,
    id_outil INTEGER NOT NULL,
    statut VARCHAR(20) DEFAULT 'EN_ATTENTE', 
    date_demande DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_utilisateur) REFERENCES utilisateurs(id) ON DELETE CASCADE,
    FOREIGN KEY (id_outil) REFERENCES outils(id),
    CONSTRAINT check_queue_statut CHECK (statut IN ('EN_ATTENTE', 'EN_COURS', 'TERMINE', 'ERREUR'))
);

-- 5. TABLE HISTORIQUE_SCANS

CREATE TABLE IF NOT EXISTS historique_scans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    id_utilisateur INTEGER,
    cible VARCHAR(255),
    id_outil INTEGER NOT NULL,
    date_debut DATETIME DEFAULT CURRENT_TIMESTAMP,
    date_fin DATETIME NULL,
    resultat_json TEXT, 
    FOREIGN KEY (id_utilisateur) REFERENCES utilisateurs(id) ON DELETE SET NULL,
    FOREIGN KEY (id_outil) REFERENCES outils(id)
);

-- 6. TABLE SERVICES

CREATE TABLE IF NOT EXISTS services (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    id_equipement INTEGER NOT NULL,
    port INTEGER NOT NULL CHECK (port BETWEEN 1 AND 65535),
    protocole VARCHAR(10) DEFAULT 'TCP',
    nom_service VARCHAR(50),
    version_service VARCHAR(100),
    etat VARCHAR(20) DEFAULT 'OPEN',
    FOREIGN KEY (id_equipement) REFERENCES equipements(id) ON DELETE CASCADE
);

-- 7. TABLE VULNERABILITES

CREATE TABLE IF NOT EXISTS vulnerabilites (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    id_equipement INTEGER NOT NULL,
    titre_faille VARCHAR(255),
    description TEXT,
    solution TEXT,
    gravite VARCHAR(20),
    cve_id VARCHAR(20),
    score_cvss REAL,
    id_outil_source INTEGER, 
    FOREIGN KEY (id_equipement) REFERENCES equipements(id) ON DELETE CASCADE,
    FOREIGN KEY (id_outil_source) REFERENCES outils(id)
);

-- ==============================================================================
-- JEU DE DONNÉES DE TEST
-- ==============================================================================

-- Outil par défaut
INSERT OR IGNORE INTO outils (nom_outil, nom_classe_java, description) VALUES 
('NESSUS', 'NessusScanner', 'Scanner de vulnérabilités complet'),
('NMAP', 'NmapScanner', 'Scanner de ports et services');

-- Admin par défaut
INSERT OR IGNORE  INTO utilisateurs (username, password_hash, role) VALUES ('jeremy', 'gj404268', 'ADMIN');

-- Exemples Equipements
INSERT OR IGNORE INTO equipements (ip, mac_address, nom_hote, os_detecte) 
VALUES ('192.168.1.25', 'AA:BB:CC:DD:EE:FF', 'Serveur-Compta', 'Linux Ubuntu 20.04');

-- Exemples Services
INSERT OR IGNORE INTO services (id_equipement, port, nom_service, version_service) 
VALUES (1, 22, 'ssh', 'OpenSSH 8.2'), (1, 80, 'http', 'Apache 2.4.41');

-- Exemple Vulnérabilité
INSERT OR IGNORE INTO vulnerabilites (id_equipement, titre_faille, gravite, cve_id, solution, id_outil_source) 
VALUES (1, 'Apache HTTP Server Path Traversal', 'CRITICAL', 'CVE-2021-41773', 'Update Apache.', 1);