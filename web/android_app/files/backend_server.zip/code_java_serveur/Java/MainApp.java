import java.util.List;

public class MainApp {

    public static void main(String[] args) {
        if (args.length < 2) {
            System.out.println("Usage: java -jar app.jar <MODE> <CIBLE> [OUTIL]");
            return;
        }

        DbManager db = new DbManager();
        String mode = args[0].toUpperCase();
        String cible = args[1];
        String nomOutil = (args.length >= 3) ? args[2] : "NMAP";

        try {
            OutilScan scanner = ScanFactory.getScanner(nomOutil);

            switch (mode) {
                case "GLOBAL":
                    System.out.println("[AUTO] Scan Réseau : " + cible);
                    List<Equipement> machines = scanner.lancerScan(cible);
                    
                    int limite = Math.min(machines.size(), 3);
                    for (Equipement eq : machines.subList(0, limite)) {
                        traiterEtSauvegarder(eq, scanner, db);
                    }
                    break;

                case "DETAIL":
                    System.out.println("[AUTO] Scan Détail : " + cible);
                    traiterEtSauvegarder(new Equipement(cible, "Inconnue", "Inconnu"), scanner, db);
                    break;

                case "MONITOR":
                    int statut = scanner.checkStatut(cible);
                    db.updateStatut(cible, statut);
                    break;

                default:
                    System.out.println("Mode inconnu : " + mode);
            }
        } catch (Exception e) {
            System.err.println("[ERREUR] " + e.getMessage());
        }
    }

    private static void traiterEtSauvegarder(Equipement eq, OutilScan scanner, DbManager db) {
        System.out.println("   -> Analyse de " + eq.getIp() + "...");
        eq.setStatut(1);
        
        scanner.scanDetaille(eq);
        
        db.sauvegarderEquipement(eq);
        db.sauvegarderServices(eq);
        db.sauvegarderVulnerabilites(eq);
        
        System.out.println("[OK] Données enregistrées pour " + eq.getIp());
    }
}