import java.util.ArrayList;
import java.util.List;

public class AuditService implements OutilScan {

    @Override
    public String getNom() {
        return "AUDIT_INTERNE";
    }

    @Override
    public List<Equipement> lancerScan(String sousReseau) {
        System.out.println("[AUDIT] Simulation de scan sur : " + sousReseau);
        List<Equipement> resultats = new ArrayList<>();
        
        Equipement serveurTest = new Equipement("192.168.1.254", "AA:BB:CC:DD:EE:FF", "Serveur-Audit-Test", "Linux (Audit)");
        resultats.add(serveurTest);
        
        return resultats;
    }

    @Override
    public void scanDetaille(Equipement cible) {
        System.out.println("[AUDIT] Analyse de conformité : " + cible.getAddIP());
        
        cible.ajouterService(new Service(2222, "TCP", "ssh-secure", "open", "OpenSSH 9.0 (Hardened)"));

        cible.ajouterVulnerabilite(new Vulnerabilite(
            "Certificat SSL Expiré",
            "MEDIUM", 
            "CVE-2023-MOCK", 
            "Renouveler le certificat sur le serveur de production."
        ));
    }

    @Override
    public int checkStatut(String ip) {
        return 1; 
    }
}