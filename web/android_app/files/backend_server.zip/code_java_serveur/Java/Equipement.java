import java.util.ArrayList;
import java.util.List;

public class Equipement {
    private int idE; 
    private String addIP;
    private String addMAC;
    private String modele;
    private String type;
    private int statut;

    private List<Service> services = new ArrayList<>();
    private List<Vulnerabilite> vulnerabilites = new ArrayList<>();

    public Equipement(String addIP, String addMAC, String modele, String type) {
        this.addIP = addIP;
        this.addMAC = addMAC;
        this.modele = modele;
        this.type = type;
        this.statut = 0;
    }

    public Equipement(String addIP, String addMAC, String modele) {
        this(addIP, addMAC, modele, "Inconnu");
    }
    public String getAddIP() { 
        return addIP; 
    }
    
    public String getIp() { 
        return addIP; 
    } 

    public String getAddMAC() { 
        return addMAC; 
    }

    public String getModele() { 
        return modele; 
    } 
    public void setModele(String modele) { 
        this.modele = modele; 
    }

    public String getType() { 
        return type; 
    } 
    public void setType(String type) { 
        this.type = type; 
    }

    public int getStatut() { 
        return statut; 
    }
    public void setStatut(int statut) { 
        this.statut = statut; 
    }

    public void setId(int id) { 
        this.idE = id; 
    }
    public int getId() { 
        return idE; 
    }

    public void ajouterService(Service s) { 
        this.services.add(s); 
    }
    public List<Service> getServices() { 
        return services; 
    }

    public void ajouterVulnerabilite(Vulnerabilite v) { 
        this.vulnerabilites.add(v); 
    }
    public List<Vulnerabilite> getVulnerabilites() { 
        return vulnerabilites; 
    }

    @Override
    public String toString() {
        return addIP + " (" + type + ")";
    }
}