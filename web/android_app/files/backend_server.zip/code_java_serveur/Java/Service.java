public class Service {
    private int port;
    private String protocole;
    private String nom;
    private String etat;
    private String version;

    public Service(int port, String protocole, String nom, String etat, String version) {
        this.port = port;
        this.protocole = protocole;
        this.nom = nom;
        this.etat = etat;
        this.version = version;
    }

    public int getPort() { 
        return port; 
    }
    
    public String getProtocole() { 
        return protocole; 
    }

    public String getNom() {
         return nom; 
        }

    public String getEtat() { 
        return etat; 
    }

    public String getVersion() { 
        return version; 
    }

    @Override
    public String toString() {
        return port + "/" + protocole + " (" + etat + ") : " + nom;
    }
}