public class Vulnerabilite {
    private String titre;
    private String gravite;
    private String cve;
    private String solution;

    public Vulnerabilite(String titre, String gravite, String cve, String solution) {
        this.titre = titre;
        this.gravite = gravite;
        this.cve = cve;
        this.solution = solution;
    }

    public String getTitre() { 
        return titre; 
    }

    public String getGravite() { 
        return gravite; 
    }

    public String getCve() { 
        return cve; 
    }

    public String getSolution() { 
        return solution; 
    }

    @Override
    public String toString() {
        return "[" + gravite + "] " + titre + " (" + cve + ")";
    }
}