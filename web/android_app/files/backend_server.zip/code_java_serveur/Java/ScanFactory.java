public class ScanFactory {

    public static OutilScan getScanner(String nomOutil) {
        switch (nomOutil.toUpperCase()) {
            case "NMAP":
                return new NmapService();
            
            case "AUDIT":
                return new AuditService();
            
            default:
                throw new IllegalArgumentException("Outil inconnu ou non implémenté : " + nomOutil);
        }
    }
}