import java.util.List;

public interface OutilScan {
    List<Equipement> lancerScan(String cible);
    
    void scanDetaille(Equipement cible); 

    String getNom();

    int checkStatut(String ip);
}