import java.io.*;
import java.util.*;

public class NmapService implements OutilScan {

    @Override
    public String getNom() { return "NMAP"; }

    private List<String> exec(String... args) {
        List<String> output = new ArrayList<>();
        try {
            Process p = new ProcessBuilder(args).start();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                String line;
                while ((line = r.readLine()) != null) output.add(line);
            }
            p.waitFor();
        } catch (Exception e) { e.printStackTrace(); }
        return output;
    }

    @Override
    public List<Equipement> lancerScan(String sousReseau) {
        List<Equipement> equipements = new ArrayList<>();
        String currentIp = null, currentMac = "Inconnue", currentVendor = "Inconnu";

        for (String line : exec("nmap", "-sn", sousReseau)) {
            if (line.contains("Nmap scan report for")) {
                if (currentIp != null) equipements.add(new Equipement(currentIp, currentMac, currentVendor, "Hôte"));
                currentIp = line.substring(line.lastIndexOf(" ") + 1).replaceAll("[()]", "");
                currentMac = "Inconnue"; currentVendor = "Inconnu";
            } else if (line.contains("MAC Address:")) {
                String[] parts = line.split("MAC Address: | \\(");
                currentMac = parts[1].trim();
                if (parts.length > 2) currentVendor = parts[2].replace(")", "").trim();
            }
        }
        if (currentIp != null) equipements.add(new Equipement(currentIp, currentMac, currentVendor, "Hôte"));
        return equipements;
    }

    @Override
    public void scanDetaille(Equipement cible) {
        for (String line : exec("nmap", "-F", "-sV", "--script", "vuln", "-O", cible.getAddIP())) {
            
            if (line.contains("OS details:")) {
                cible.setType(line.split(":")[1].trim());
            }

            if (line.matches(".*\\d+/(tcp|udp).*")) {
                String[] p = line.split("\\s+", 4);
                String[] pt = p[0].split("/");
                cible.ajouterService(new Service(Integer.parseInt(pt[0]), pt[1].toUpperCase(), p[2], p[1], p.length > 3 ? p[3] : ""));
            }

            if (line.contains("CVE-")) {
                int start = line.indexOf("CVE-");
                String cve = line.substring(start, Math.min(start + 14, line.length())).trim();
                if (cible.getVulnerabilites().stream().noneMatch(v -> v.getCve().equals(cve))) {
                    cible.ajouterVulnerabilite(new Vulnerabilite("Faille " + cve, "HIGH", cve, "Voir Nmap/CVE"));
                }
            }
        }
    }

    @Override
    public int checkStatut(String ip) {
        return exec("nmap", "-sn", ip).stream().anyMatch(l -> l.contains("Host is up")) ? 1 : 0;
    }
}