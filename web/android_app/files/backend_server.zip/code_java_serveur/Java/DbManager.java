import java.sql.*;
import java.util.List;

public class DbManager {
    private String url = "jdbc:sqlite:bdd.db";

    public DbManager() {
        try {
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException e) {
            System.err.println("Driver SQLite manquant !");
        }
    }

    private Connection connect() throws SQLException {
        return DriverManager.getConnection(url);
    }

    public void sauvegarderEquipement(Equipement eq) {
        String sql = "INSERT INTO equipements(ip, mac_address, nom_hote, os_detecte, statut) VALUES(?,?,?,?,?) " +
                     "ON CONFLICT(ip) DO UPDATE SET mac_address=excluded.mac_address, nom_hote=excluded.nom_hote, " +
                     "os_detecte=excluded.os_detecte, statut=excluded.statut";

        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setString(1, eq.getAddIP());
            pstmt.setString(2, eq.getAddMAC());
            pstmt.setString(3, eq.getModele());
            pstmt.setString(4, eq.getType());
            pstmt.setInt(5, 1);
            pstmt.executeUpdate();

            ResultSet rs = pstmt.getGeneratedKeys();
            if (rs.next()) eq.setId(rs.getInt(1));

        } catch (SQLException e) { System.out.println("Erreur Equipement: " + e.getMessage()); }
    }

    public void sauvegarderServices(Equipement eq) {
        if (eq.getId() == 0) sauvegarderEquipement(eq);

        String sqlDel = "DELETE FROM services WHERE id_equipement = ?";
        String sqlIns = "INSERT INTO services (id_equipement, port, protocole, nom_service, etat, version_service) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = connect()) {
            try (PreparedStatement pDel = conn.prepareStatement(sqlDel)) {
                pDel.setInt(1, eq.getId());
                pDel.executeUpdate();
            }
            try (PreparedStatement pIns = conn.prepareStatement(sqlIns)) {
                for (Service s : eq.getServices()) {
                    pIns.setInt(1, eq.getId());
                    pIns.setInt(2, s.getPort());
                    pIns.setString(3, s.getProtocole());
                    pIns.setString(4, s.getNom());
                    pIns.setString(5, s.getEtat());
                    pIns.setString(6, s.getVersion());
                    pIns.addBatch(); 
                }
                pIns.executeBatch();
            }
        } catch (SQLException e) { System.out.println("Erreur Services: " + e.getMessage()); }
    }

    public void sauvegarderVulnerabilites(Equipement eq) {
        if (eq.getId() == 0) return;

        String sql = "INSERT INTO vulnerabilites (titre_faille, gravite, cve_id, solution, id_equipement) VALUES (?, ?, ?, ?, ?)";
        
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            for (Vulnerabilite v : eq.getVulnerabilites()) {
                pstmt.setString(1, v.getTitre());
                pstmt.setString(2, v.getGravite());
                pstmt.setString(3, v.getCve());
                pstmt.setString(4, v.getSolution());
                pstmt.setInt(5, eq.getId());
                pstmt.addBatch();
            }
            pstmt.executeBatch();
            
        } catch (SQLException e) { System.out.println("Erreur Failles: " + e.getMessage()); }
    }

    public void updateStatut(String ip, int statut) {
        String sql = "UPDATE equipements SET statut = ? WHERE ip = ?";
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, statut);
            pstmt.setString(2, ip);
            pstmt.executeUpdate();
        } catch (SQLException e) { System.out.println("Erreur Statut: " + e.getMessage()); }
    }
}